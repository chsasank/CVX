# CVX
Project from Convex Optimization course

Financial portifolio optimization with linear and fixed transaction costs 
